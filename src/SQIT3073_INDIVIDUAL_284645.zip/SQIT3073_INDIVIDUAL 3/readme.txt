If you are using Windows, please extract the zip files to C:/ directory
If you are using MacOS, please extract the zip files to download directory
Kindly check if your pc is using python or python3
.cmd files are for Windows
.command files are for MacOS 

Q: what should i do if i cannot run the autorun.cmd on mac?

A: run the command below using terminal:
chmod +x "/Users/yourusername/Downloads/SQIT3073_INDIVIDUAL_284645/autorun(python).command"
change yourusername according to your pc name
maintain python or using python3
